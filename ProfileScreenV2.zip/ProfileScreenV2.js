app.controller("profileController", function ($scope, $http) {
    $scope.Title = "";
    $scope.Description = "";
    $scope.attachment = false;
    const profileQFTemp = dataFetching("Quick%20Forms", "?$select=*");
    $scope.profileQuickForms = profileQFTemp;
});
