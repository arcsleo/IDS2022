var app = angular.module('myApp', []);

app.controller('circularControlelr', function ($scope, $http) {
    CircularTemp = dataFetching("Circular", "?$select=FileRef,FileLeafRef,Author/Title,Author/EMail,*&$Expand=Author");
    console.log($scope.Circular);
    const tempData = [];
    CircularTemp.forEach((value, index)=>{
        tempData.push({
            FileRef: value.FileRef,
            Image: value.Image,
            Author: value.Author,
            Modified: value.Modified,
            FileLeafRef: value.FileLeafRef.split(".")[0]
        });
    });
    $scope.Circular = CircularTemp;
});