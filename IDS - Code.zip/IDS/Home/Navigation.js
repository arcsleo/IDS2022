function scrollDetect() {
  var lastScroll = 0;

  window.onscroll = function () {
    let currentScroll =
      document.documentElement.scrollTop || document.body.scrollTop; // Get Current Scroll Value

    if (currentScroll != 0) {
      document.getElementById("TopNavId").classList.add("navfixed");
    } else {
      document.getElementById("TopNavId").classList.remove("navfixed");
    }
  };
}

window.onload = function (e) {
  scrollDetect();
};
