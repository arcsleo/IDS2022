var app = angular.module("myApp", []);

app.controller("trainingController", function ($scope, $http) {
  $scope.count = 5;
  $scope.starting = 0;
  $scope.activePage = 1;
  $scope.ending = $scope.count;
  $scope.Data = [
    {
      Title: "Branding: The Creative Journey 1",
      Category: "Branding",
      Owner: "Colin Felton",
      Created: "Jan 4, 2023",
      Modified: "Katie Lew",
      LastModified: "Jan 4, 2023",
    },
    {
      Title: "Customer Interaction Basics 2",
      Category: "Sales",
      Owner: "Colin Felton",
      Created: "Feb 4, 2023",
      Modified: "Katie Lew",
      LastModified: "Feb 4, 2023",
    },
    {
      Title: "Branding 3",
      Category: "General",
      Owner: "Colin Felton",
      Created: "Dec 4, 2023",
      Modified: "Katie Lew",
      LastModified: "Dec 4, 2023",
    },
    {
      Title: "Branding: The Creative Journey 4",
      Category: "Branding",
      Owner: "Colin Felton",
      Created: "Jan 4, 2023",
      Modified: "Katie Lew",
      LastModified: "Jan 4, 2023",
    },
    {
      Title: "Customer Interaction Basics 5",
      Category: "Sales",
      Owner: "Colin Felton",
      Created: "Jan 4, 2023",
      Modified: "Katie Lew",
      LastModified: "Jan 4, 2023",
    },
    {
      Title: "Branding 6",
      Category: "General",
      Owner: "Colin Felton",
      Created: "Jan 4, 2023",
      Modified: "Katie Lew",
      LastModified: "Jan 4, 2023",
    },
    {
      Title: "Branding: The Creative Journey 7",
      Category: "Branding",
      Owner: "Colin Felton",
      Created: "Jan 4, 2023",
      Modified: "Katie Lew",
      LastModified: "Jan 4, 2023",
    },
    {
      Title: "Customer Interaction Basics 8",
      Category: "Sales",
      Owner: "Colin Felton",
      Created: "Jan 4, 2023",
      Modified: "Katie Lew",
      LastModified: "Jan 4, 2023",
    },
    {
      Title: "Branding 9",
      Category: "General",
      Owner: "Colin Felton",
      Created: "Jan 4, 2023",
      Modified: "Katie Lew",
      LastModified: "Jan 4, 2023",
    },
    {
      Title: "Branding: The Creative Journey 10",
      Category: "Branding",
      Owner: "Colin Felton",
      Created: "Dec 4, 2023",
      Modified: "Katie Lew",
      LastModified: "Dec 4, 2023",
    },
    {
      Title: "Customer Interaction Basics 11",
      Category: "Sales",
      Owner: "Colin Felton",
      Created: "Mar 4, 2023",
      Modified: "Katie Lew",
      LastModified: "Mar 4, 2023",
    },
    {
      Title: "Branding 12",
      Category: "General",
      Owner: "Colin Felton",
      Created: "Jan 4, 2023",
      Modified: "Katie Lew",
      LastModified: "Jan 4, 2023",
    },
  ];
  // $scope.pageCount = Math.round($scope.Data.length / $scope.count);
  if (Number.isInteger($scope.Data.length / $scope.count)) {
    $scope.pageCount = parseInt($scope.Data.length / $scope.count);
  } else {
    $scope.pageCount = parseInt($scope.Data.length / $scope.count) + 1;
  }
  $scope.next = () => {
    $scope.starting = $scope.ending;
    $scope.ending = $scope.ending + $scope.count;
    $scope.activePage += 1;
  };
  $scope.prev = () => {
    $scope.ending = $scope.starting;
    $scope.starting = $scope.ending - $scope.count;
    $scope.activePage -= 1;
  };
  $scope.first = () => {
    $scope.activePage = 1;
    $scope.starting = 0;
    $scope.ending = $scope.count;
  };
  $scope.last = () => {
    $scope.activePage = $scope.pageCount;
    if ($scope.Data.length % $scope.count === 0) {
      $scope.starting = $scope.Data.length - $scope.count;
    } else {
      $scope.starting =
        $scope.Data.length - ($scope.Data.length % $scope.count);
    }
    $scope.ending = $scope.Data.length;
  };
});
