var app = angular.module('myApp', []);

app.controller('circularControlelr', function ($scope, $http) {
    CircularTemp = dataFetching("News", "?$select=FileRef,FileLeafRef,Author/Title,Author/EMail,*&$Expand=Author");
    console.log($scope.Circular);
    const tempData = [];
    CircularTemp.forEach((value, index)=>{
        tempData.push({
            FileRef: value.FileRef,
            Image: value.Image,
            Author: value.Author,
            Modified: `${new Date(value.Modified).getDate()}/${new Date(value.Modified).getMonth() + 1}/${new Date(value.Modified).getFullYear()}`,
            FileLeafRef: value.FileLeafRef.split(".")[0],
            UserLogo: _spPageContextInfo.siteServerRelativeUrl + "/_layouts/15/userphoto.aspx?size=L&accountname=" + value.Author.EMail
        });
    });
    $scope.Circular = tempData;
});