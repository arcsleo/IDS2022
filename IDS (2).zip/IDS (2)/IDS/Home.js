var app = angular.module('myApp', []);

app.controller('myController', function ($scope, $http) {
    $scope.Banner = dataFetching("Banner");
    $scope.Announcements = dataFetching("Announcements");
    $scope.Message = dataFetching("Message");
    $scope.NavBar = dataFetching("Nav%20Bar");
    $scope.News = dataFetching("News");
    $scope.CircularList = dataFetching("CircularList");
    $scope.QuickLinks = dataFetching("Quick%20Links");
    
    console.log(dataFetching("Test"));
});