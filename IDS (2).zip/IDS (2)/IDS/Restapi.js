function dataFetching(listName) {
    var returnData = [];
    $.ajax({
        url: `http://u01vusgdipweb01/sites/UAQIntranet/_api/web/lists/GetByTitle('${listName}')/items`,
        type: "GET",
        async: false,
        headers: {
            "accept": "application/json;odata=verbose",
        },
        success: function (data) {
            returnData = data.d.results;
            console.log(returnData);
        },
        error: function (error) {
            console.log(JSON.stringify(error));
        }
    });
    return returnData;
}